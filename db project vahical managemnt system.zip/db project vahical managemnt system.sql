-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: vehicle_management
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `application_settings`
--

DROP TABLE IF EXISTS `application_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `application_settings` (
  `application_id` int NOT NULL,
  `Tax_amount` double DEFAULT NULL,
  `currency_symbol` varchar(128) DEFAULT NULL,
  `Created_at` datetime DEFAULT NULL,
  `Updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`application_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_settings`
--

LOCK TABLES `application_settings` WRITE;
/*!40000 ALTER TABLE `application_settings` DISABLE KEYS */;
INSERT INTO `application_settings` VALUES (101,15,'USD','2024-05-01 10:00:00','2024-05-01 10:00:00'),(102,18.5,'EUR','2024-05-02 11:00:00','2024-05-02 11:00:00'),(103,20,'GBP','2024-05-03 12:00:00','2024-05-03 12:00:00'),(104,10,'INR','2024-05-04 13:00:00','2024-05-04 13:00:00'),(105,12,'AUD','2024-05-05 14:00:00','2024-05-05 14:00:00'),(106,8.5,'CAD','2024-05-06 15:00:00','2024-05-06 15:00:00'),(107,22,'JPY','2024-05-07 16:00:00','2024-05-07 16:00:00'),(108,5,'CNY','2024-05-08 17:00:00','2024-05-08 17:00:00'),(109,7.5,'CHF','2024-05-09 18:00:00','2024-05-09 18:00:00'),(1010,9,'BRL','2024-05-10 19:00:00','2024-05-10 19:00:00');
/*!40000 ALTER TABLE `application_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `claims`
--

DROP TABLE IF EXISTS `claims`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `claims` (
  `claims_id` int NOT NULL,
  `insurance_id` int DEFAULT NULL,
  `claim_reasons` varchar(128) DEFAULT NULL,
  `claim_approved_on` datetime DEFAULT NULL,
  `claim_status` varchar(64) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`claims_id`),
  KEY `insurance_id` (`insurance_id`),
  CONSTRAINT `claims_ibfk_1` FOREIGN KEY (`insurance_id`) REFERENCES `insurance` (`insurance_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `claims`
--

LOCK TABLES `claims` WRITE;
/*!40000 ALTER TABLE `claims` DISABLE KEYS */;
INSERT INTO `claims` VALUES (7001,6001,'Accident damage','2024-05-01 12:00:00','Approved','2024-05-01 10:00:00','2024-05-01 12:00:00',0),(7002,6002,'Theft',NULL,'Pending','2024-05-02 11:00:00','2024-05-02 11:00:00',0),(7003,6003,'Natural disaster','2024-05-03 14:00:00','Approved','2024-05-03 12:00:00','2024-05-03 14:00:00',0),(7004,6004,'Vandalism','2024-05-04 15:00:00','Rejected','2024-05-04 13:00:00','2024-05-04 15:00:00',0),(7005,6005,'Fire damage',NULL,'Pending','2024-05-05 14:00:00','2024-05-05 14:00:00',0),(7006,6006,'Flood damage','2024-05-06 16:00:00','Approved','2024-05-06 15:00:00','2024-05-06 16:00:00',0),(7007,6007,'Collision','2024-05-07 18:00:00','Approved','2024-05-07 16:00:00','2024-05-07 18:00:00',0),(7008,6008,'Hail damage',NULL,'Pending','2024-05-08 17:00:00','2024-05-08 17:00:00',0),(7009,6009,'Mechanical failure','2024-05-09 19:00:00','Approved','2024-05-09 18:00:00','2024-05-09 19:00:00',0),(7010,6010,'Roadside assistance','2024-05-10 20:00:00','Rejected','2024-05-10 19:00:00','2024-05-10 20:00:00',0);
/*!40000 ALTER TABLE `claims` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `insurance`
--

DROP TABLE IF EXISTS `insurance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `insurance` (
  `insurance_id` int NOT NULL,
  `sales_id` int DEFAULT NULL,
  `Insurance_category` varchar(64) DEFAULT NULL,
  `is_paid` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`insurance_id`),
  KEY `sales_id` (`sales_id`),
  CONSTRAINT `insurance_ibfk_1` FOREIGN KEY (`sales_id`) REFERENCES `sales` (`sales_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insurance`
--

LOCK TABLES `insurance` WRITE;
/*!40000 ALTER TABLE `insurance` DISABLE KEYS */;
INSERT INTO `insurance` VALUES (6001,3001,'Comprehensive',1,'2024-05-01 10:00:00','2024-05-01 10:05:00',0),(6002,3002,'Third Party',0,'2024-05-02 11:00:00','2024-05-02 11:05:00',0),(6003,3003,'Comprehensive',1,'2024-05-03 12:00:00','2024-05-03 12:05:00',0),(6004,3004,'Third Party',0,'2024-05-04 13:00:00','2024-05-04 13:05:00',0),(6005,3005,'Comprehensive',1,'2024-05-05 14:00:00','2024-05-05 14:05:00',0),(6006,3006,'Third Party',1,'2024-05-06 15:00:00','2024-05-06 15:05:00',0),(6007,3007,'Comprehensive',0,'2024-05-07 16:00:00','2024-05-07 16:05:00',0),(6008,3008,'Third Party',1,'2024-05-08 17:00:00','2024-05-08 17:05:00',0),(6009,3009,'Comprehensive',0,'2024-05-09 18:00:00','2024-05-09 18:05:00',0),(6010,3010,'Third Party',1,'2024-05-10 19:00:00','2024-05-10 19:05:00',0);
/*!40000 ALTER TABLE `insurance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory` (
  `inventory_id` int NOT NULL,
  `vehical_name` varchar(128) DEFAULT NULL,
  `Make` varchar(128) DEFAULT NULL,
  `Model` varchar(128) DEFAULT NULL,
  `Color` varchar(128) DEFAULT NULL,
  `vehical_Engine` varchar(128) DEFAULT NULL,
  `Fuel_Type` varchar(128) DEFAULT NULL,
  `Fuel_Capacity` varchar(128) DEFAULT NULL,
  `Mileage` varchar(128) DEFAULT NULL,
  `is_Used` tinyint(1) DEFAULT NULL,
  `Plate` varchar(64) DEFAULT NULL,
  `showroom_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`inventory_id`),
  KEY `showroom_id` (`showroom_id`),
  CONSTRAINT `inventory_ibfk_1` FOREIGN KEY (`showroom_id`) REFERENCES `showroom` (`showroom_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES (2001,'Ford Mustang','Ford','Mustang','Red','5.0L V8','Gasoline','61L','15mpg',1,'XYZ789',2,'2024-05-28 11:00:00','2024-05-28 11:00:00',0),(2002,'Chevrolet Camaro','Chevrolet','Camaro','Black','6.2L V8','Gasoline','62L','14mpg',1,'DEF234',3,'2024-05-28 13:00:00','2024-05-28 13:00:00',0),(2003,'BMW 3 Series','BMW','3 Series','Silver','2.0L I4','Diesel','55L','25mpg',0,'GHI345',4,'2024-05-28 14:00:00','2024-05-28 14:00:00',0),(2004,'Audi A4','Audi','A4','Gray','2.0L I4','Gasoline','60L','24mpg',1,'JKL567',2,'2024-05-28 15:00:00','2024-05-28 15:00:00',0),(2005,'Mercedes-Benz C-Class','Mercedes-Benz','C-Class','Blue','2.0L I4','Gasoline','66L','22mpg',0,'MNO678',3,'2024-05-28 16:00:00','2024-05-28 16:00:00',0),(2006,'Tesla Model S','Tesla','Model S','White','Electric','Electric','100kWh','102mpge',0,'PQR890',4,'2024-05-28 17:00:00','2024-05-28 17:00:00',0),(2007,'Hyundai Sonata','Hyundai','Sonata','Red','2.5L I4','Gasoline','60L','27mpg',0,'VWX234',2,'2024-05-28 19:00:00','2024-05-28 19:00:00',0),(2008,'Toyota Corolla','Toyota','Corolla','White','1.8L I4','Gasoline','50L','30mpg',0,'ABC123',1,'2024-05-28 10:00:00','2024-05-28 10:00:00',0),(2009,'Volkswagen Golf','Volkswagen','Golf','Green','1.4L I4','Gasoline','55L','28mpg',1,'STU901',1,'2024-05-28 18:00:00','2024-05-28 18:00:00',0),(2010,'Hyundai Sonata','Hyundai','Sonata','Red','2.5L I4','Gasoline','60L','27mpg',0,'VWX234',7,'2024-05-28 19:00:00','2024-05-28 19:00:00',0);
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment` (
  `payment_id` int NOT NULL,
  `sales_id` int DEFAULT NULL,
  `is_installment` tinyint(1) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `currency_symbol` varchar(16) DEFAULT NULL,
  `payment_method` varchar(16) DEFAULT NULL,
  `payment_type` varchar(16) DEFAULT NULL,
  `sender_name` varchar(128) DEFAULT NULL,
  `sender__account` varchar(128) DEFAULT NULL,
  `Receiver_account` varchar(128) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `sales_id` (`sales_id`),
  CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`sales_id`) REFERENCES `sales` (`sales_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` VALUES (4001,3001,0,10500,'$','Credit Card','One-time','John Doe','123456789','987654321','2024-05-01 10:00:00','2024-05-01 10:05:00',0),(4002,3002,1,5000,'$','Bank Transfer','Installment','Jane Smith','223456789','887654321','2024-05-02 11:00:00','2024-05-02 11:05:00',0),(4003,3002,1,10500,'$','Bank Transfer','Installment','Jane Smith','223456789','887654321','2024-05-03 12:00:00','2024-05-03 12:05:00',0),(4004,3003,0,20500,'€','Credit Card','One-time','Alice Johnson','323456789','787654321','2024-05-04 13:00:00','2024-05-04 13:05:00',0),(4005,3004,1,12500,'€','Bank Transfer','Installment','Bob Brown','423456789','687654321','2024-05-05 14:00:00','2024-05-05 14:05:00',0),(4006,3004,1,13000,'€','Bank Transfer','Installment','Bob Brown','423456789','687654321','2024-05-06 15:00:00','2024-05-06 15:05:00',0),(4007,3005,0,30500,'£','Credit Card','One-time','Charlie Davis','523456789','587654321','2024-05-07 16:00:00','2024-05-07 16:05:00',0),(4008,3006,1,17500,'£','Bank Transfer','Installment','Diana Clark','623456789','487654321','2024-05-08 17:00:00','2024-05-08 17:05:00',0),(4009,3006,1,18000,'£','Bank Transfer','Installment','Diana Clark','623456789','487654321','2024-05-09 18:00:00','2024-05-09 18:05:00',0),(4010,3007,0,40500,'¥','Credit Card','One-time','Edward Evans','723456789','387654321','2024-05-10 19:00:00','2024-05-10 19:05:00',0);
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `price`
--

DROP TABLE IF EXISTS `price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `price` (
  `price_id` int NOT NULL,
  `old_value` varchar(128) DEFAULT NULL,
  `new_value` varchar(128) DEFAULT NULL,
  `currency_symbol` varchar(16) DEFAULT NULL,
  `inventory_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`price_id`),
  KEY `inventory_id` (`inventory_id`),
  CONSTRAINT `price_ibfk_1` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`inventory_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price`
--

LOCK TABLES `price` WRITE;
/*!40000 ALTER TABLE `price` DISABLE KEYS */;
INSERT INTO `price` VALUES (1001,'10000','10500','$',2001,'2024-05-01 10:00:00','2024-05-01 10:05:00',0),(1002,'15000','15500','$',2002,'2024-05-02 11:00:00','2024-05-02 11:05:00',0),(1003,'20000','20500','€',2003,'2024-05-03 12:00:00','2024-05-03 12:05:00',0),(1004,'25000','25500','€',2004,'2024-05-04 13:00:00','2024-05-04 13:05:00',0),(1005,'30000','30500','£',2005,'2024-05-05 14:00:00','2024-05-05 14:05:00',0),(1006,'35000','35500','£',2006,'2024-05-06 15:00:00','2024-05-06 15:05:00',0),(1007,'40000','40500','¥',2007,'2024-05-07 16:00:00','2024-05-07 16:05:00',0),(1008,'45000','45500','¥',2008,'2024-05-08 17:00:00','2024-05-08 17:05:00',0),(1009,'50000','50500','$',2009,'2024-05-09 18:00:00','2024-05-09 18:05:00',0),(1010,'55000','55500','$',2010,'2024-05-10 19:00:00','2024-05-10 19:05:00',0);
/*!40000 ALTER TABLE `price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `role_id` int NOT NULL,
  `role_name` varchar(128) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (8001,'Admin','2024-05-01 10:00:00','2024-05-01 10:00:00'),(8002,'Manager','2024-05-02 11:00:00','2024-05-02 11:00:00'),(8003,'User','2024-05-03 12:00:00','2024-05-03 12:00:00'),(8004,'Technician','2024-05-04 13:00:00','2024-05-04 13:00:00'),(8005,'Salesperson','2024-05-05 14:00:00','2024-05-05 14:00:00'),(8006,'Customer Support','2024-05-06 15:00:00','2024-05-06 15:00:00'),(8007,'Accountant','2024-05-07 16:00:00','2024-05-07 16:00:00'),(8008,'Logistics','2024-05-08 17:00:00','2024-05-08 17:00:00'),(8009,'IT Support','2024-05-09 18:00:00','2024-05-09 18:00:00'),(8010,'Marketing','2024-05-10 19:00:00','2024-05-10 19:00:00');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales` (
  `sales_id` int NOT NULL,
  `inventory_id` int DEFAULT NULL,
  `selling_price` double DEFAULT NULL,
  `currency_symbol` varchar(16) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`sales_id`),
  KEY `inventory_id` (`inventory_id`),
  CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`inventory_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (3001,2001,10500,'$','2024-05-01 10:00:00','2024-05-01 10:05:00',0),(3002,2002,15500,'$','2024-05-02 11:00:00','2024-05-02 11:05:00',0),(3003,2003,20500,'€','2024-05-03 12:00:00','2024-05-03 12:05:00',0),(3004,2004,25500,'€','2024-05-04 13:00:00','2024-05-04 13:05:00',0),(3005,2005,30500,'£','2024-05-05 14:00:00','2024-05-05 14:05:00',0),(3006,2006,35500,'£','2024-05-06 15:00:00','2024-05-06 15:05:00',0),(3007,2007,40500,'¥','2024-05-07 16:00:00','2024-05-07 16:05:00',0),(3008,2008,45500,'¥','2024-05-08 17:00:00','2024-05-08 17:05:00',0),(3009,2009,50500,'$','2024-05-09 18:00:00','2024-05-09 18:05:00',0),(3010,2010,55500,'$','2024-05-10 19:00:00','2024-05-10 19:05:00',0);
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `services` (
  `Services_id` int NOT NULL,
  `inventory_id` int DEFAULT NULL,
  `Service_type` varchar(128) DEFAULT NULL,
  `service_charges` varchar(128) DEFAULT NULL,
  `receive_date` datetime DEFAULT NULL,
  `delivery_date` datetime DEFAULT NULL,
  `isCompleted` tinyint(1) DEFAULT NULL,
  `customer_review` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`Services_id`),
  KEY `inventory_id` (`inventory_id`),
  CONSTRAINT `services_ibfk_1` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`inventory_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES (5001,2001,'Repair','$100','2024-05-01 10:00:00','2024-05-05 15:00:00',1,'Excellent service','2024-05-01 09:00:00','2024-05-05 16:00:00',0),(5002,2002,'Maintenance','$150','2024-05-02 11:00:00','2024-05-06 14:00:00',0,'','2024-05-02 10:00:00','2024-05-06 13:00:00',0),(5003,2003,'Installation','$200','2024-05-03 12:00:00','2024-05-07 13:00:00',1,'Very satisfied','2024-05-03 11:00:00','2024-05-07 14:00:00',0),(5004,2004,'Cleaning','$50','2024-05-04 13:00:00','2024-05-08 12:00:00',1,'Good job','2024-05-04 12:00:00','2024-05-08 13:00:00',0),(5005,2005,'Upgrade','$250','2024-05-05 14:00:00','2024-05-09 11:00:00',0,'','2024-05-05 13:00:00','2024-05-09 10:00:00',0),(5006,2006,'Repair','$120','2024-05-06 15:00:00','2024-05-10 10:00:00',1,'Excellent work','2024-05-06 14:00:00','2024-05-10 11:00:00',0),(5007,2007,'Maintenance','$180','2024-05-07 16:00:00','2024-05-11 09:00:00',1,'Highly recommended','2024-05-07 15:00:00','2024-05-11 10:00:00',0),(5008,2008,'Installation','$220','2024-05-08 17:00:00','2024-05-12 08:00:00',0,'','2024-05-08 16:00:00','2024-05-12 07:00:00',0),(5009,2009,'Cleaning','$60','2024-05-09 18:00:00','2024-05-13 07:00:00',1,'Satisfied','2024-05-09 17:00:00','2024-05-13 08:00:00',0),(5010,2010,'Upgrade','$270','2024-05-10 19:00:00','2024-05-14 06:00:00',0,'','2024-05-10 18:00:00','2024-05-14 05:00:00',0);
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `showroom`
--

DROP TABLE IF EXISTS `showroom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `showroom` (
  `showroom_id` int NOT NULL,
  `showroom_name` varchar(128) DEFAULT NULL,
  `location` varchar(128) DEFAULT NULL,
  `inventory_limit` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`showroom_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `showroom`
--

LOCK TABLES `showroom` WRITE;
/*!40000 ALTER TABLE `showroom` DISABLE KEYS */;
INSERT INTO `showroom` VALUES (1,'Downtown Showroom','123 Main St',50,'2024-05-01 08:00:00','2024-05-01 08:00:00',0),(2,'Uptown Showroom','456 Elm St',60,'2024-05-02 09:00:00','2024-05-02 09:00:00',0),(3,'Westside Showroom','789 Pine St',70,'2024-05-03 10:00:00','2024-05-03 10:00:00',0),(4,'Eastside Showroom','321 Oak St',80,'2024-05-04 11:00:00','2024-05-04 11:00:00',0),(5,'Northside Showroom','654 Maple St',90,'2024-05-05 12:00:00','2024-05-05 12:00:00',0),(6,'Southside Showroom','987 Cedar St',100,'2024-05-06 13:00:00','2024-05-06 13:00:00',0),(7,'Central Showroom','543 Birch St',110,'2024-05-07 14:00:00','2024-05-07 14:00:00',0),(8,'Beachside Showroom','876 Palm St',120,'2024-05-08 15:00:00','2024-05-08 15:00:00',0),(9,'Lakeside Showroom','765 Lake St',130,'2024-05-09 16:00:00','2024-05-09 16:00:00',0),(10,'Mountain View Showroom','654 Mountain St',140,'2024-05-10 17:00:00','2024-05-10 17:00:00',0);
/*!40000 ALTER TABLE `showroom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` int NOT NULL,
  `user_Name` varchar(128) DEFAULT NULL,
  `Email` varchar(128) DEFAULT NULL,
  `user_Password` binary(1) DEFAULT NULL,
  `role_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (9001,'John Doe','john.doe@example.com',_binary '1',8001,'2024-05-01 10:00:00','2024-05-01 10:00:00',0),(9002,'Jane Smith','jane.smith@example.com',_binary '1',8002,'2024-05-02 11:00:00','2024-05-02 11:00:00',0),(9003,'Robert Brown','robert.brown@example.com',_binary '1',8003,'2024-05-03 12:00:00','2024-05-03 12:00:00',0),(9004,'Emily Davis','emily.davis@example.com',_binary '0',8004,'2024-05-04 13:00:00','2024-05-04 13:00:00',0),(9005,'Michael Wilson','michael.wilson@example.com',_binary '0',8005,'2024-05-05 14:00:00','2024-05-05 14:00:00',0),(9006,'Sarah Johnson','sarah.johnson@example.com',_binary '1',8006,'2024-05-06 15:00:00','2024-05-06 15:00:00',0),(9007,'David Lee','david.lee@example.com',_binary '0',8007,'2024-05-07 16:00:00','2024-05-07 16:00:00',0),(9008,'Laura Martinez','laura.martinez@example.com',_binary '1',8008,'2024-05-08 17:00:00','2024-05-08 17:00:00',0),(9009,'James Anderson','james.anderson@example.com',_binary '0',8009,'2024-05-09 18:00:00','2024-05-09 18:00:00',0),(9010,'Patricia Thomas','patricia.thomas@example.com',_binary '0',8010,'2024-05-10 19:00:00','2024-05-10 19:00:00',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-23 11:30:53
